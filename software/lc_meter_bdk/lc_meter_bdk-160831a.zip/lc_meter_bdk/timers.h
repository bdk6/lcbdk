

#ifndef TIMERS_H_
#define TIMERS_H_

void Timers_Init(void);

uint32_t Timers_readCount(void);

#endif

